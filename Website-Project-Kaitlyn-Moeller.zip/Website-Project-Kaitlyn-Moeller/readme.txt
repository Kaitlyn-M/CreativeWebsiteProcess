"Welcome to the Vale's!" About
------------------------------
Home/Index: A summary of the website's purpose and completition statuses. It also provides helpful navigation and audio information.
About: The website author's education, hobbies and likes.
Characters: A list of the author's original characters. Each character section contains an image and detailed descriptions.
Stories: The author's story ideas, future intentions and directions to the user.
Games: The author's game ideas and future intentions.
Contact: All of the author's contact information.

Page names
----------
Home - Welcome to the Vale! (index.html)
About - Welcome to the Vale! (about.html)
Characters - Welcome to the Vale! (characters.html)
Stories - Welcome to the Vale! (stories.html)
Games - Welcome to the Vale! (games.html)
Contact - Welcome to the Vale! (contact.html)
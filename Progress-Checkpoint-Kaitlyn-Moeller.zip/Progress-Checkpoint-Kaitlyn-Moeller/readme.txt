Assignment Requirements:

Validate to check for errors using: http://html5.validator.nu  or http://validator.w3.org
Include a description of what the page(s) output in a readme.txt. Include the page name in your readme.txt file.
Use Good formatted, easy to read and commented code.
User Friendly interface, including readable output, Interface is self explaining
All files and folders zipped correctly.
Label your zip file, with the assignment name + your name.zip
Solution is written for problem assigned and includes all required functionality.

Page names:
about.html, characters.html, contact.html, games.html, index.html, stories.html, characters-stories-games.css, home-about-contact.css
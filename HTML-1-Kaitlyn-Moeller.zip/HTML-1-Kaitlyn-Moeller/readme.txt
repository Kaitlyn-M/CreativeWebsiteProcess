Summary of website:
Each web page will have an audio player on top of the screen. Users can choose to listen, mute and/or pause the audio player.
The header has a clickable image that is linked to the homepage. When the user clicks on the link, they are directed to the homepage.
�About Me� contains information about myself. It includes my name, why I created the website, likes and hobbies.
�Characters� has information on all my original characters. Each character description includes his/her name, nickname(s), age, race, backstory, personality, strengths, weaknesses, appearance, occupation (or lack thereof) and hobbies. Additional information will be added to an aside. The aside includes how that character relates to other characters. If there is no relation, there is no aside for that character. Pictures of each character will also be included as visual aids. However, these pictures only show the head to shoulder area. 
�Stories� will have introductory or summary information based on two current stories. The first story, Ash's Volatile Time, describes my primary character�s experience in an insane asylum. Meanwhile, Call of the Void revolves around a character who experiences a major version of a phenomenon with the nickname. Images, descriptions and references will be provided for each story. The aside includes current progress/status on the stories and future ideas.
�Games� will summarize my sole game idea, �Moonlight Vale�. It is based on a Discord RP (Roleplay) server that I own. First, the game�s basic information is displayed. Patient classification and role information are specified. In this page�s aside, the game�s progress and future ideas are presented.
�Contact� has my contact information. This includes my primary g-mail account and phone number.

HTML page name:
index.html